import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicantService } from '../applicant.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  applicant!: ApplicantDetails;
  applicants!: any;
  pending!:any[];

  constructor(private router: Router, private applicantService: ApplicantService) {
    if (sessionStorage.getItem('isLoggedIn') != 'true') {
      this.router.navigate(['/login']);
    }
  }

  ngOnInit(): void {
    this.getAllApplicants();
   
  }

  getAllApplicants() {
    this.applicantService.getAllApplicantsService().subscribe({
      next: (data) => {

        this.applicants = data
        
      } ,
      error: (error) => alert('Something went wrong..' + error.error.message)
    });
  }



}
