import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApplicantDetails } from './applicant/ApplicantDetails';

@Injectable({
  providedIn: 'root'
})
export class ApplicantService {
  BaseURL = 'http://localhost:8080/bankadmin/';
  constructor(private http: HttpClient) { }

  getApplicantByIdService(id: number) {
    return this.http.get(this.BaseURL + 'getApplicantById/' + id);
  }

  getAllApplicantsService() {
    return this.http.get(this.BaseURL + 'getAllApplicants');
  }

  updateApplicantService(applicant: ApplicantDetails) {
    return this.http.put(this.BaseURL + 'updateBankApplicant', applicant);
  }



}
