import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicantService } from '../applicant.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  applicantDetails!: any;
  loader:boolean = false;
  constructor(private applicantService: ApplicantService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(map => {
      let appId = map.get('appId');
      this.applicantService.getApplicantByIdService(Number(appId)).subscribe({
        next: (data) => this.applicantDetails = data,
        error: (error) => alert('Something went wrong..' + error.error.message)
      });
    });

  }


  goBack() {
    this.router.navigate(['/home']);
  }

  updateApplicant(applicant: any, status: string) {
    applicant.applicationStatus = status;
    let msg;
    if (status == 'Approved') {

       msg = 'Are you sure to approve this applicant ?';
    }
    else {
       msg = 'Are you sure to reject this applicant ?';
    }
    if (confirm(msg)) {
      this.loader = true;
     
      this.applicantService.updateApplicantService(applicant).subscribe({
        next: (data) => {
          if (status == 'Approved') {
            alert('Applicant approved successfully.!!');
            this.loader = false;
            this.goBack();
          }
          else {
            alert('Applicant rejected successfully.!!');
            this.loader = false;
            this.goBack();
          }
        },
        error: (error) => alert('Something went wrong...' + error.error.message)
      });
    }
  }

}
