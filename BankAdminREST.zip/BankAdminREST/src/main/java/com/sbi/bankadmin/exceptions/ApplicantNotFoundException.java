package com.sbi.bankadmin.exceptions;

public class ApplicantNotFoundException extends RuntimeException {
	public ApplicantNotFoundException(String msg) {
		super(msg);
	}
}
