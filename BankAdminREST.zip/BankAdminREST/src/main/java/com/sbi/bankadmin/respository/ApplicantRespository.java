package com.sbi.bankadmin.respository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sbi.bankadmin.pojo.BankApplicant;

@Repository
public interface ApplicantRespository extends CrudRepository<BankApplicant, Integer> {

}
