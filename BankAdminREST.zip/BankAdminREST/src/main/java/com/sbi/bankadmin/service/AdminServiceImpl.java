package com.sbi.bankadmin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.bankadmin.exceptions.ApplicantNotFoundException;
import com.sbi.bankadmin.pojo.BankApplicant;
import com.sbi.bankadmin.respository.ApplicantRespository;

@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	ApplicantRespository applicantRespository;

	@Override
	public BankApplicant findBankApplicantByIdService(int applicantId) {
		// TODO Auto-generated method stub
		Optional<BankApplicant> bankApplicant = applicantRespository.findById(applicantId);
		if (bankApplicant.isPresent()) {
			return bankApplicant.get();
		} else {
			throw new ApplicantNotFoundException("Applicant is not found..");
		}
	}

	@Override
	public List<BankApplicant> findAllBankApplicantsService() {
		// TODO Auto-generated method stub
		List<BankApplicant> applicantList = (List<BankApplicant>) applicantRespository.findAll();
		if (applicantList.size() > 0) {
			return applicantList;
		} else {
			throw new ApplicantNotFoundException("Applicants not found..");
		}
	}

	@Override
	public void updateBankApplicantService(BankApplicant applicantObj) {
		// TODO Auto-generated method stub
		if (applicantRespository.existsById(applicantObj.getApplicantId())) {
			applicantRespository.save(applicantObj);
		}
		else {
			throw new ApplicantNotFoundException("Applicant is not found..");
		}
	}
	
	public void addBankApplicantService(BankApplicant applicantObj) {
		if (applicantRespository.existsById(applicantObj.getApplicantId())) {
			throw new ApplicantNotFoundException("Applicant already exists.");
		}
		else {
			
			applicantRespository.save(applicantObj);
		}
	}

}
