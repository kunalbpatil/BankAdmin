package com.sbi.bankadmin.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.sbi.bankadmin.exceptions.ApplicantNotFoundException;
import com.sbi.bankadmin.pojo.BankApplicant;
import com.sbi.bankadmin.respository.ApplicantRespository;

@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	ApplicantRespository applicantRespository;

	@Autowired
	MailService mailService;
	
	@Override
	public BankApplicant findBankApplicantByIdService(int applicantId) {
		// TODO Auto-generated method stub
		Optional<BankApplicant> bankApplicant = applicantRespository.findById(applicantId);
		if (bankApplicant.isPresent()) {
			return bankApplicant.get();
		} else {
			throw new ApplicantNotFoundException("Applicant is not found..");
		}
	}

	@Override
	public List<BankApplicant> findAllBankApplicantsService() {
		// TODO Auto-generated method stub
		List<BankApplicant> applicantList = (List<BankApplicant>) applicantRespository.findAll();
		if (applicantList.size() > 0) {
			return applicantList;
		} else {
			throw new ApplicantNotFoundException("Applicants not found..");
		}
	}

	@Override
	public void updateBankApplicantService(BankApplicant applicantObj) {
		// TODO Auto-generated method stub
		if (applicantRespository.existsById(applicantObj.getApplicantId())) {
			applicantRespository.save(applicantObj);
			if(applicantObj.getApplicationStatus().equalsIgnoreCase("approved")) {
				mailService.sendMail("Dear Customer,<br><br> Your application with applicant id : <b>"
				        +applicantObj.getApplicantId()+"</b> got <b>"+applicantObj.getApplicationStatus().toLowerCase()+"<b> for account opening.<br> "
				        + "Thank You for Banking With Us!..<br><br> Regards,<br>SBI Admin Team", applicantObj.getEmail());
					System.out.println("approval mail sent...");
			}
			else if(applicantObj.getApplicationStatus().equalsIgnoreCase("rejected")) {
				mailService.sendMail("Dear Customer,<br><br> Your application with applicant id : <b>"+applicantObj.getApplicantId()
				+"</b> got <b>"+applicantObj.getApplicationStatus()+"</b> due to <b>"+ applicantObj.getRemarks() +"</b>. Please visit the branch for further clarification. <br><br> Regards,<br>SBI Admin Team", applicantObj.getEmail());
				System.out.println("Rejection mail sent...");
			}
		}
		else {
			throw new ApplicantNotFoundException("Applicant is not found..");
		}
	}
	
	public void addBankApplicantService(BankApplicant applicantObj) {
		if (applicantRespository.existsById(applicantObj.getApplicantId())) {
			throw new ApplicantNotFoundException("Applicant already exists.");
		}
		else {
			
			applicantRespository.save(applicantObj);
		}
	}

}
