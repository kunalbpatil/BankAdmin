package com.sbi.bankadmin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.bankadmin.pojo.BankApplicant;

@Service
public interface AdminService {
	public BankApplicant findBankApplicantByIdService(int applicantId);
	public List<BankApplicant> findAllBankApplicantsService();
	public void updateBankApplicantService(BankApplicant applicantObj);
	public void addBankApplicantService(BankApplicant applicantObj);
}
