package com.sbi.bankadmin.service;

public interface MailService {
	public void sendMail(String info, String email);
}
