package com.sbi.bankadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAdminRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAdminRestApplication.class, args);
	}

}
