package com.sbi.bankadmin.controller;

public class ResponseStatus {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
