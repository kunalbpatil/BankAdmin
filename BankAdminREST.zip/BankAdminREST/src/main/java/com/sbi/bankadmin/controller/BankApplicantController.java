package com.sbi.bankadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.bankadmin.pojo.BankApplicant;
import com.sbi.bankadmin.service.AdminService;

@RestController
@RequestMapping("/bankadmin")
public class BankApplicantController {
	@Autowired
	AdminService adminService;

	@RequestMapping("/getApplicantById/{aid}")
	public ResponseEntity getBankApplicantById(@PathVariable("aid") int applicantId) {
		BankApplicant applicant;
		ResponseEntity<BankApplicant> resp;
		ResponseStatus respStatus = new ResponseStatus();
		try {
			applicant = adminService.findBankApplicantByIdService(applicantId);
			return ResponseEntity.ok(applicant);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			respStatus.setMessage(e.getMessage());
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(respStatus);
		}

	}

	@RequestMapping("/getAllApplicants")
	public ResponseEntity getAllBankApplicants() {
		List<BankApplicant> applicantList;
		ResponseEntity resp;
		ResponseStatus respStatus = new ResponseStatus();
		try {
			applicantList = adminService.findAllBankApplicantsService();
			return ResponseEntity.ok(applicantList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			respStatus.setMessage(e.getMessage());
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(respStatus);
		}

	}

	@PutMapping("/updateBankApplicant")
	public ResponseEntity updateBankApplicant(@RequestBody BankApplicant applicantObj) {

		ResponseEntity resp;
		ResponseStatus respStatus = new ResponseStatus();
		try {
			BankApplicant applicant = adminService.findBankApplicantByIdService(applicantObj.getApplicantId());

			adminService.updateBankApplicantService(applicantObj);
			return ResponseEntity.ok(applicantObj);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			respStatus.setMessage(e.getMessage());
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(respStatus);
		}

	}

}
