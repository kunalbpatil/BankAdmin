package com.sbi.bankadmin;

import java.sql.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.bankadmin.pojo.BankApplicant;
import com.sbi.bankadmin.service.AdminService;

@SpringBootTest
class BankAdminRestApplicationTests {
	@Autowired
	AdminService adminService;
	
	@Test
	void updateApplicantTest() {
		BankApplicant ba=new BankApplicant();
		BankApplicant bankAppl2=new BankApplicant();
		BankApplicant bankAppl3=new BankApplicant();
		BankApplicant bankAppl4=new BankApplicant();
		
		ba.setTitle("Mr.");
		ba.setAddress("Flat 302, FR heights");
		ba.setAnnualIncome(400000L);
		ba.setApplicantId(101);
		ba.setApplicationDate(Date.valueOf("2022-10-06"));
		ba.setApplicationStatus("Pending");
		ba.setApplyingFor("Savings Ac");
		ba.setDateOfBirth(Date.valueOf("1988-08-08"));
		ba.setEduQualification("BTech");
		ba.setEmail("abc@gmail.com");
		ba.setFatherName("Amitabh");
		ba.setFirstName("Abhishek");
		ba.setGender("Male");
		ba.setGuardianAddress("Belapur");
		ba.setGuardianName("Amitabh");
		ba.setIdNumber("ABCD456PT");
		ba.setIdType("PAN Card");
		ba.setLastName("Bachan");
		ba.setMaritalStatus("Married");
		ba.setMiddleName("A");
		ba.setMotherName("Jaya");
		ba.setNomineeAddress("Mumbai");
		ba.setNomineeDOB(Date.valueOf("1988-08-09"));
		ba.setNomineeName("Amitabh");
		ba.setNomineeRelationship("Father");
		ba.setOccupation("Actor");
		ba.setPanCard("ABCD456PT");
		ba.setPhoneNumber(9856475123L);
		ba.setReligion("Hindu");
		ba.setSpouseName("Aishwarya");
		ba.setRemarks("KYC Provided");
		
		adminService.addBankApplicantService(ba);
		
		
	}

}
